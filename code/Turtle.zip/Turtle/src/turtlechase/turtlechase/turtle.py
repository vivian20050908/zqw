from os import kill
import rclpy
from rclpy.node import Node
from turtlesim.srv import Spawn
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist
import random
import math

class TurtleChase(Node):
    def __init__(self):
        super().__init__('turtle_chase')

        self.turtleA_name = 'turtle1'
        self.turtleB_name = 'turtle2'

        self.client = self.create_client(kill, '/kill')
        while not self.client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Kill service not available, waiting...')
        
        # 删除现有的`turtle2`
        req = kill.Request()
        req.name = self.turtleB_name
        self.client.call_async(req)

        # 重新生成`turtle2`
        self.spawn_client = self.create_client(Spawn, '/spawn')
        while not self.spawn_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Spawn service not available, waiting...')
        
        spawn_req = Spawn.Request()
        spawn_req.x = 5.0
        spawn_req.y = 5.0
        spawn_req.theta = 0.0
        spawn_req.name = self.turtleB_name
        self.spawn_client.call_async(spawn_req)

        self.get_logger().info(f"Spawned {self.turtleB_name}")

        # 继续下面的初始化和追逐逻辑...
def main(args=None):
    rclpy.init(args=args)
    turtle_chase = TurtleChase()
    rclpy.spin(turtle_chase)
    turtle_chase.destroy_node()
    rclpy.shutdown()